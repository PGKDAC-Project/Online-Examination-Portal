package com.oep.entities;

public enum ExamStatus {
    SCHEDULED,
    ONGOING,
    COMPLETED,
    CANCELLED
}
