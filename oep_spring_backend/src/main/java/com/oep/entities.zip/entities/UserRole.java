package com.oep.entities;

public enum UserRole {
	ROLE_ADMIN, ROLE_INSTRUCTOR, ROLE_STUDENT
}
