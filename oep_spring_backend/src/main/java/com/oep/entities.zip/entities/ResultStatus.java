package com.oep.entities;

public enum ResultStatus {
	 PASS, FAIL, PENDING
}
