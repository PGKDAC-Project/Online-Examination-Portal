package com.oep.entities;

public enum Status {
	ACTIVE, INACTIVE, SUSPENDED
}
