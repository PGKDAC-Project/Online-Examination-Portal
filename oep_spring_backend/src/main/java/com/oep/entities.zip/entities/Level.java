package com.oep.entities;

public enum Level {
	EASY, MEDIUM, DIFFICULT
}
