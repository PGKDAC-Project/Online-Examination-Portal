package com.oep.entities;

public enum QuestionType {
	SINGLE, MULTIPLE, TRUE_FALSE, MATCHING
}
